import { createContext } from "react";

// Create context
const alertContext = createContext();

export default alertContext;
