import { createContext } from "react";

// Create context
const authContext = createContext();

export default authContext;
