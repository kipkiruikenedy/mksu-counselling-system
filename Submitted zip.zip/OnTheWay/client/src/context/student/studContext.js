import { createContext } from "react";

// Create context
const studContext = createContext();

export default studContext;
